import os

from ament_index_python.packages import get_package_prefix, get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, SetEnvironmentVariable, TimerAction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    sim_share = get_package_share_directory("ican_delivery_sim")
    sim_prefix = get_package_prefix("ican_delivery_sim")
    world_path = os.path.join(sim_share, "worlds", "delivery_task2.world")
    rviz_config_path = os.path.join(sim_share, "rviz", "delivery_sensors.rviz")
    gui = LaunchConfiguration("gui")
    rviz = LaunchConfiguration("rviz")
    use_sim_time = LaunchConfiguration("use_sim_time")

    return LaunchDescription(
        [
            DeclareLaunchArgument("gui", default_value="true", description="Start Gazebo GUI client."),
            DeclareLaunchArgument(
                "rviz",
                default_value="false",
                description="Start RViz with UAV camera image and lidar point cloud displays.",
            ),
            DeclareLaunchArgument("use_sim_time", default_value="true"),
            SetEnvironmentVariable(
                "GAZEBO_PLUGIN_PATH",
                os.path.join(sim_prefix, "lib") + ":" + os.environ.get("GAZEBO_PLUGIN_PATH", ""),
            ),
            ExecuteProcess(
                cmd=[
                    "gzserver",
                    world_path,
                    "-s",
                    "libgazebo_ros_init.so",
                    "-s",
                    "libgazebo_ros_factory.so",
                    "-s",
                    "libgazebo_ros_force_system.so",
                ],
                output="screen",
            ),
            TimerAction(
                period=4.0,
                actions=[
                    ExecuteProcess(
                        cmd=["gzclient"],
                        output="screen",
                        condition=IfCondition(gui),
                    )
                ],
            ),
            Node(
                package="tf2_ros",
                executable="static_transform_publisher",
                name="uav_base_to_camera_tf",
                arguments=[
                    "--x", "0.390",
                    "--y", "0",
                    "--z", "0.130",
                    "--roll", "0",
                    "--pitch", "0",
                    "--yaw", "0",
                    "--frame-id", "uav/base_link",
                    "--child-frame-id", "uav/camera_link",
                ],
                parameters=[{"use_sim_time": use_sim_time}],
                output="screen",
            ),
            Node(
                package="tf2_ros",
                executable="static_transform_publisher",
                name="uav_base_to_lidar_tf",
                arguments=[
                    "--x", "0.120",
                    "--y", "0",
                    "--z", "0.180",
                    "--roll", "0",
                    "--pitch", "0",
                    "--yaw", "0",
                    "--frame-id", "uav/base_link",
                    "--child-frame-id", "uav/lidar_link",
                ],
                parameters=[{"use_sim_time": use_sim_time}],
                output="screen",
            ),
            TimerAction(
                period=6.0,
                actions=[
                    Node(
                        package="rviz2",
                        executable="rviz2",
                        name="delivery_sensors_rviz",
                        arguments=["-d", rviz_config_path],
                        parameters=[{"use_sim_time": use_sim_time}],
                        output="screen",
                        condition=IfCondition(rviz),
                    )
                ],
            ),
        ]
    )
